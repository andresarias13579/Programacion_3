namespace Matematicas;
public class Impresion{
	public static void Imprimir(String mensaje){
		Console.WriteLine(mensaje);
	}
	public static String Saludar(String nombre){
		return "Hola " + nombre;
	}
}